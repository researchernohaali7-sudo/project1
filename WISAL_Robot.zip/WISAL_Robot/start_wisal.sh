#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
printf '\nWISAL: http://127.0.0.1:8000\nPress Ctrl+C to stop.\n'
.venv/bin/python -m uvicorn wisal.server:app --host 127.0.0.1 --port 8000
