@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python was not found. Use WISAL_Robot_Colab.ipynb or install Python 3.11+ from python.org.
  pause
  exit /b 1
)
if not exist .venv\Scripts\python.exe py -3 -m venv .venv
if errorlevel 1 goto fail
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto fail
start "WISAL" http://127.0.0.1:8000
.venv\Scripts\python.exe -m uvicorn wisal.server:app --host 127.0.0.1 --port 8000
goto end
:fail
echo Could not start WISAL. Check Python and internet access, or use Colab.
pause
:end
endlocal
