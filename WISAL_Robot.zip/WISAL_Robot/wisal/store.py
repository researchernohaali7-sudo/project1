"""SQLite room storage with compare-and-swap revisions and per-participant keys."""
import hashlib
import json
import secrets
import sqlite3
from pathlib import Path
from uuid import uuid4
from .domain import new_state, apply, ROLES
from .medical import timestamp, require, short

class Conflict(Exception): pass
class Forbidden(Exception): pass

def digest(value): return hashlib.sha256(value.encode()).hexdigest()

class Store:
    def __init__(self, directory):
        self.directory = Path(directory); self.directory.mkdir(parents=True, exist_ok=True)
        self.path = self.directory / 'rooms.sqlite3'
        with self.connect() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS rooms (id TEXT PRIMARY KEY, secret_hash TEXT NOT NULL, state TEXT NOT NULL, revision INTEGER NOT NULL);
                CREATE TABLE IF NOT EXISTS members (id TEXT PRIMARY KEY, room_id TEXT NOT NULL, token_hash TEXT NOT NULL, role TEXT NOT NULL, name TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS members_room ON members(room_id);
            ''')
    def connect(self):
        db = sqlite3.connect(self.path, timeout=10); db.row_factory = sqlite3.Row
        return db
    @staticmethod
    def room(db, room_id):
        row = db.execute('SELECT * FROM rooms WHERE id=?', (room_id,)).fetchone()
        if row is None or json.loads(row['state'])['expires_at'] <= timestamp(): raise Forbidden('الجلسة غير متاحة أو انتهت صلاحيتها')
        return row
    def create(self, name):
        name = short(name, 40); require(name, 'أدخلي اسم العرض')
        room_id, key = str(uuid4()), secrets.token_urlsafe(32)
        with self.connect() as db:
            db.execute('INSERT INTO rooms VALUES (?,?,?,0)', (room_id, digest(key), json.dumps(new_state(), ensure_ascii=False)))
        member = self.join(room_id, key, name, 'operator')
        return {'room_id': room_id, 'join_key': key, **member}
    def join(self, room_id, key, name, role):
        name = short(name, 40); require(name and role in ROLES, 'اسم أو دور غير صالح')
        member_id, token, now = str(uuid4()), secrets.token_urlsafe(32), timestamp()
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE'); row = self.room(db, room_id)
            if not secrets.compare_digest(row['secret_hash'], digest(key)): raise Forbidden('رابط انضمام غير صحيح')
            state = json.loads(row['state']); online = [p for p in state['participants'] if now - p['last_seen'] < 45000]
            require(len(online) < 12, 'الغرفة ممتلئة؛ الحد 12 مشاركة متصلة')
            state['participants'] = [p for p in state['participants'] if now - p['last_seen'] < 3600000]
            state['participants'].append({'id': member_id, 'name': name, 'role': role, 'last_seen': now})
            db.execute('INSERT INTO members VALUES (?,?,?,?,?)', (member_id, room_id, digest(token), role, name))
            db.execute('UPDATE rooms SET state=?, revision=revision+1 WHERE id=?', (json.dumps(state, ensure_ascii=False), room_id))
        return {'member_id': member_id, 'member_token': token, 'role': role, 'name': name}
    def authenticate(self, room_id, member_id, token, db=None):
        if db is None:
            with self.connect() as connection: return self.authenticate(room_id, member_id, token, connection)
        row = db.execute('SELECT * FROM members WHERE id=? AND room_id=?', (member_id, room_id)).fetchone()
        if row is None or not secrets.compare_digest(row['token_hash'], digest(token)): raise Forbidden('هوية مشاركة غير صالحة')
        self.room(db, room_id)
        return {'id': row['id'], 'name': row['name'], 'role': row['role']}
    def read(self, room_id, member_id, token):
        with self.connect() as db:
            self.authenticate(room_id, member_id, token, db); row = self.room(db, room_id)
            return {'state': json.loads(row['state']), 'revision': row['revision']}
    def mutate(self, room_id, member_id, token, revision, command):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE'); actor = self.authenticate(room_id, member_id, token, db); row = self.room(db, room_id)
            if type(revision) is not int or revision != row['revision']: raise Conflict('تغيرت البيانات من طرف آخر؛ حدّثي الجلسة')
            state = apply(json.loads(row['state']), command, actor)
            db.execute('UPDATE rooms SET state=?, revision=revision+1 WHERE id=?', (json.dumps(state, ensure_ascii=False, allow_nan=False), room_id))
            return {'state': state, 'revision': row['revision'] + 1}
    def delete(self, room_id, member_id, token):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE'); actor = self.authenticate(room_id, member_id, token, db)
            if actor['role'] != 'operator': raise Forbidden('حذف الجلسة للمشغّلة فقط')
            db.execute('DELETE FROM members WHERE room_id=?', (room_id,)); db.execute('DELETE FROM rooms WHERE id=?', (room_id,))
