"""WISAL ground-robot interactive prototype."""
__version__ = "4.0.0"
