"""Deterministic simulation. No actuator, medical-device or force-control commands."""
from copy import deepcopy
from uuid import uuid4
from .medical import require, short, timestamp, primary_observation, primary_alerts, prepare_assessment, demo_assessment, news2

ROLES = {'operator': 'المشغّلة', 'robot': 'طرف وِصال', 'medic': 'المسعف', 'observer': 'متابعة الفريق'}
LABELS = {'NEW': 'بانتظار التحقق', 'VERIFIED': 'بلاغ متحقق منه', 'ASSIGNED': 'تم التكليف', 'EN_ROUTE': 'في الطريق', 'ARRIVED': 'وصل', 'ASSESSING': 'التقييم الأولي', 'HANDOVER': 'تسليم للمسعف', 'RETURNING': 'عودة للقاعدة', 'CLOSED': 'مكتمل', 'CANCELLED': 'ملغى'}
LOCATIONS = {'gate3': 'البوابة الثالثة', 'zoneA': 'المنطقة أ', 'hall': 'صالة الفعالية'}
ACTIVE = ['ASSIGNED', 'EN_ROUTE', 'ARRIVED', 'ASSESSING', 'HANDOVER', 'RETURNING']

def new_state(now=None):
    now = timestamp() if now is None else now
    return {'schema': 4, 'created_at': now, 'expires_at': now + 8 * 3600000, 'mode': 'SIMULATION', 'clinical_approval': 'PENDING',
            'missions': [], 'participants': [], 'messages': [], 'calls': [], 'events': [],
            'robot': {'model': 'WISAL Ground', 'battery': 86, 'link': True, 'obstacle': False, 'estop': False, 'resume_required': False, 'drawer': 'CLOSED', 'arm': 'STOWED', 'person_confirmed': False}}

def event(s, kind, detail, actor, now):
    s['events'].append({'id': str(uuid4()), 'kind': kind, 'detail': detail, 'actor': actor['name'], 'at': now})
    s['events'] = s['events'][-200:]

def movement_blocks(s, mission):
    r = s['robot']; reasons = []
    for flag, expected, text in [('link', True, 'رابط الروبوت مفصول'), ('obstacle', False, 'عائق في المسار'), ('estop', False, 'التوقف الطارئ مفعّل')]:
        if r[flag] != expected: reasons.append(text)
    if r['battery'] < 20: reasons.append('البطارية أقل من حد المحاكاة 20%')
    if r['drawer'] != 'CLOSED': reasons.append('درج المستلزمات مفتوح')
    if r['arm'] != 'STOWED': reasons.append('الذراع ليس في وضع التخزين')
    if mission.get('primary', {}).get('scene') == 'unsafe': reasons.append('المشهد غير آمن وفق المشاهدة')
    return reasons

def report_for(m, now=None):
    now = timestamp() if now is None else now
    return {'mission_code': m['code'], 'location': LOCATIONS[m['location']], 'complaint': m['description'], 'verified_report': m.get('verification'),
            'primary': m.get('primary'), 'alerts': primary_alerts(m.get('primary')), 'assessment': m.get('assessment'),
            'news2': news2(m.get('assessment'), now), 'escalation': m.get('escalation'), 'source': 'SIMULATED_ONLY', 'clinical_approval': 'PENDING', 'generated_at': now}

def apply(original, command, actor, now=None):
    now = timestamp() if now is None else now
    s, c = deepcopy(original), command
    require(now < s['expires_at'], 'انتهت الجلسة؛ أنشئي جلسة جديدة')
    kind = c.get('type'); role = actor['role']; r = s['robot']
    allowed = {
        'STOP': list(ROLES), 'CREATE': ['operator', 'robot'], 'VERIFY_REPORT': ['operator'], 'ASSIGN': ['operator'], 'START_ROUTE': ['operator'], 'ADVANCE': ['operator'], 'RESUME': ['operator'], 'ROBOT': ['operator'],
        'PERSON_CONFIRM': ['operator', 'robot'], 'SAVE_PRIMARY': ['operator', 'robot', 'medic'], 'SAVE_ASSESSMENT': ['operator', 'robot', 'medic'], 'DEMO_READINGS': ['operator', 'robot', 'medic'],
        'ESCALATE': ['operator', 'robot', 'medic'], 'SEND_REPORT': ['operator', 'robot', 'medic'], 'REVIEW': ['medic'], 'RETURN': ['operator'], 'CANCEL': ['operator'],
        'CARE_AUTHORIZE': ['medic'], 'DRAWER_OPEN': ['operator', 'robot', 'medic'], 'DRAWER_CLOSE': ['operator', 'robot', 'medic'],
        'ARM_READY': ['operator', 'robot', 'medic'], 'ARM_ASSIST_DEMO': ['operator', 'robot', 'medic'], 'ARM_STOW': ['operator', 'robot', 'medic'],
        'MESSAGE': list(ROLES), 'CALL_START': ['operator', 'robot', 'medic'], 'CALL_ACCEPT': list(ROLES), 'CALL_END': list(ROLES), 'CALL_HEARTBEAT': list(ROLES), 'PRESENCE': list(ROLES),
    }
    require(kind in allowed, 'أمر غير معروف')
    require(role in allowed[kind], 'هذا الإجراء غير متاح لدورك في العرض')
    def mission():
        item = next((m for m in s['missions'] if m['id'] == c.get('id')), None)
        require(item is not None, 'المهمة غير موجودة')
        return item
    def live(m): require(m['status'] not in ['CLOSED', 'CANCELLED'], 'المهمة منتهية')
    def invalidate(m):
        m['review'] = None; m['handover'] = None
        if m['status'] == 'HANDOVER': m['status'] = 'ASSESSING'
    def care(m):
        require(m['status'] in ['ARRIVED', 'ASSESSING', 'HANDOVER'], 'يلزم الوصول والتوقف قبل استخدام المكوّن المحاكى')
        require(m.get('primary', {}).get('scene') == 'safe', 'وثقي سلامة المشهد أولًا')
        require(r['person_confirmed'], 'يلزم تحقق بشري من وجود الشخص')
        require(not primary_alerts(m.get('primary')), 'التنبيهات الأولية تحتاج مراجعة المختص؛ المكوّن المحاكى محجوب')
        require(r['link'] and not r['estop'], 'عالج سبب التوقف أولًا')
        require(m.get('care_authorization', {}).get('supervision') is True, 'يلزم تصريح المسعف وإشراف مباشر في السيناريو')
    if kind == 'PRESENCE':
        p = next((p for p in s['participants'] if p['id'] == actor['id']), None)
        require(p is not None, 'انضمي للجلسة أولًا'); p['last_seen'] = now
        return s
    if kind == 'STOP':
        r['estop'] = True; r['resume_required'] = True
        for item in s['missions']: item.pop('care_authorization', None)
        event(s, 'توقف طارئ محاكى', 'أمر توقف من مشاركة في الجلسة', actor, now)
    elif kind == 'CREATE':
        require(len(s['missions']) < 30, 'الحد الأقصى 30 بلاغًا في الجلسة')
        require(c.get('location') in LOCATIONS, 'موقع غير معروف')
        description = short(c.get('description', ''), 600); require(description, 'أدخلي وصف البلاغ')
        m = {'id': str(uuid4()), 'code': f"W-{len(s['missions'])+1:03d}", 'created_at': now, 'description': description, 'location': c['location'], 'status': 'NEW', 'progress': 0, 'return_progress': 0, 'primary': {}, 'assessment': None, 'review': None, 'handover': None}
        s['missions'].insert(0, m); event(s, 'بلاغ جديد', m['code'], actor, now)
    elif kind == 'ROBOT':
        key, value = c.get('key'), c.get('value')
        require(key in ['link', 'obstacle', 'estop', 'battery'], 'مفتاح تحكم غير صالح')
        if key == 'battery': require(type(value) is int and 0 <= value <= 100, 'نسبة بطارية غير صالحة')
        else: require(type(value) is bool, 'حالة تحكم غير صالحة')
        r[key] = value
        if not r['link'] or r['obstacle'] or r['estop'] or r['battery'] < 20:
            r['resume_required'] = True
        event(s, 'اختبار مستشعر محاكى', key + ': ' + str(value), actor, now)
    elif kind in ['CALL_START', 'CALL_ACCEPT', 'CALL_END', 'CALL_HEARTBEAT']:
        s['calls'] = [x for x in s['calls'] if now - x['updated_at'] < 300000]
        if kind == 'CALL_START':
            m = mission(); live(m)
            target = next((p for p in s['participants'] if p['id'] == c.get('target_id') and now - p['last_seen'] < 45000), None)
            require(target is not None and target['id'] != actor['id'], 'اختاري طرفًا آخر متصلًا')
            require(c.get('mode') in ['audio', 'video', 'test'], 'نوع اتصال غير صالح')
            involved = [actor['id'], target['id']]
            require(not any(x['status'] != 'ended' and now - x['updated_at'] < 90000 and (x['from'] in involved or x['to'] in involved) for x in s['calls']), 'أحد الطرفين مشغول')
            s['calls'].append({'id': str(uuid4()), 'mission_id': m['id'], 'from': actor['id'], 'to': target['id'], 'mode': c['mode'], 'status': 'ringing', 'created_at': now, 'updated_at': now})
        else:
            call = next((x for x in s['calls'] if x['id'] == c.get('call_id')), None)
            require(call is not None and actor['id'] in [call['from'], call['to']], 'المكالمة غير متاحة')
            if kind == 'CALL_ACCEPT':
                require(actor['id'] == call['to'] and call['status'] == 'ringing' and now - call['created_at'] <= 60000, 'انتهى طلب الاتصال')
                call['status'] = 'connected'
            elif kind == 'CALL_END': call['status'] = 'ended'
            else: require(call['status'] != 'ended', 'انتهت المكالمة')
            call['updated_at'] = now
    else:
        m = mission(); live(m)
        if kind == 'VERIFY_REPORT':
            require(m['status'] == 'NEW' and c.get('confirmed') is True, 'يلزم تحقق بشري صريح من البلاغ')
            m['verification'] = {'actor': actor['name'], 'at': now, 'source': 'HUMAN_DEMO'}; m['status'] = 'VERIFIED'
        elif kind == 'ASSIGN':
            require(m['status'] == 'VERIFIED', 'تحققي من البلاغ قبل التكليف')
            require(not any(x['status'] in ACTIVE for x in s['missions']), 'وِصال مشغول بمهمة أخرى')
            require(not movement_blocks(s, m), 'عالج أسباب منع الحركة أولًا')
            m['status'] = 'ASSIGNED'; r['person_confirmed'] = False
        elif kind == 'START_ROUTE':
            require(m['status'] == 'ASSIGNED', 'كلفي وِصال أولًا'); require(not movement_blocks(s, m), 'الحركة غير مسموحة')
            m['status'] = 'EN_ROUTE'; r['resume_required'] = False
        elif kind == 'ADVANCE':
            require(m['status'] in ['EN_ROUTE', 'RETURNING'], 'لا توجد حركة في هذه المرحلة')
            reasons = movement_blocks(s, m)
            require(not reasons and not r['resume_required'], 'المحاكاة متوقفة: ' + '، '.join(reasons or ['يلزم استئناف صريح']))
            key = 'return_progress' if m['status'] == 'RETURNING' else 'progress'
            m[key] = min(100, m[key] + 20); r['battery'] = max(0, r['battery'] - 1)
            if m[key] == 100:
                m['status'] = 'CLOSED' if key == 'return_progress' else 'ARRIVED'
                if key == 'return_progress':
                    r['person_confirmed'] = False
                    for call in s['calls']:
                        if call['mission_id'] == m['id']: call.update(status='ended', updated_at=now)
        elif kind == 'RESUME':
            require(m['status'] in ['EN_ROUTE', 'RETURNING'], 'لا يوجد مسار جارٍ')
            require(not movement_blocks(s, m), 'سبب التوقف ما زال قائمًا'); r['resume_required'] = False
        elif kind == 'PERSON_CONFIRM':
            require(m['status'] in ['ARRIVED', 'ASSESSING', 'HANDOVER'] and c.get('confirmed') is True, 'يلزم وصول وتحقق بشري صريح')
            r['person_confirmed'] = True
        elif kind == 'SAVE_PRIMARY':
            require(m['status'] != 'RETURNING', 'المهمة في العودة')
            if 'base_primary_saved_at' in c: require(c['base_primary_saved_at'] == (m['primary'] or {}).get('saved_at'), 'تغيرت المشاهدة من طرف آخر؛ افتحي أحدث نسخة')
            m['primary'] = primary_observation(c.get('primary', {}), now); invalidate(m); m.pop('care_authorization', None)
            if m['primary']['scene'] == 'unsafe': r['resume_required'] = True
        elif kind in ['SAVE_ASSESSMENT', 'DEMO_READINGS']:
            require(m['status'] in ['ARRIVED', 'ASSESSING', 'HANDOVER'], 'ابدئي القياسات بعد الوصول')
            if 'base_saved_at' in c: require(c['base_saved_at'] == (m['assessment'] or {}).get('saved_at'), 'تغير التقييم من طرف آخر؛ افتحي أحدث نسخة')
            a = demo_assessment(c.get('complete') is True, now) if kind == 'DEMO_READINGS' else prepare_assessment(c.get('assessment', {}), now)
            observed = m.get('primary', {}).get('response')
            require(not (observed in ['V', 'P', 'U'] and a['consciousness'] not in [None, observed]), 'حالة الوعي لا تتفق مع المشاهدة الأولية؛ راجعي الإدخال')
            m['assessment'] = a; m['status'] = 'ASSESSING'; invalidate(m); m.pop('care_authorization', None)
        elif kind == 'ESCALATE':
            m['escalation'] = {'at': now, 'actor': actor['name'], 'reason': short(c.get('reason', 'طلب مراجعة فورية'), 600), 'scope': 'INTERNAL_DEMO_ONLY'}
        elif kind == 'SEND_REPORT':
            require(m['status'] in ['ASSESSING', 'HANDOVER'] and m['assessment'] is not None, 'احفظي التقييم قبل التسليم')
            m['handover'] = report_for(m, now); m['review'] = None; m['status'] = 'HANDOVER'
        elif kind == 'REVIEW':
            require(m['status'] == 'HANDOVER' and m['handover'], 'أرسلي التقرير أولًا')
            note = short(c.get('note', ''), 800); require(note, 'سجلي ملاحظة المراجعة')
            m['review'] = {'at': now, 'actor': actor['name'], 'note': note, 'demo_role': 'medic'}
        elif kind == 'RETURN':
            require(m['status'] == 'HANDOVER' and m['review'], 'يلزم تسليم التقرير ومراجعته قبل العودة')
            require(not movement_blocks(s, m), 'أغلقي الدرج وخزني الذراع وعالجي التوقف قبل العودة')
            m['status'] = 'RETURNING'; r['resume_required'] = False
        elif kind == 'CANCEL':
            m['status'] = 'CANCELLED'; r['resume_required'] = True
            for call in s['calls']:
                if call['mission_id'] == m['id']: call.update(status='ended', updated_at=now)
        elif kind == 'CARE_AUTHORIZE':
            require(m['status'] in ['ARRIVED', 'ASSESSING', 'HANDOVER'], 'يلزم الوصول أولًا')
            require(c.get('supervision') is True and c.get('consent') is True, 'يلزم تأكيد الإشراف والموافقة في سيناريو العرض')
            m['care_authorization'] = {'actor': actor['name'], 'at': now, 'supervision': True, 'consent': True, 'scope': 'SIMULATION_ONLY'}
        elif kind == 'DRAWER_OPEN': care(m); r['drawer'] = 'OPEN'
        elif kind == 'DRAWER_CLOSE': r['drawer'] = 'CLOSED'
        elif kind == 'ARM_READY': care(m); require(r['arm'] == 'STOWED', 'خزني الذراع أولًا'); r['arm'] = 'READY'
        elif kind == 'ARM_ASSIST_DEMO': care(m); require(r['arm'] == 'READY', 'جهزي الذراع المحاكى أولًا'); r['arm'] = 'ASSIST_DEMO'
        elif kind == 'ARM_STOW': require(not r['estop'], 'فكي التوقف قبل إعادة الذراع المحاكى'); r['arm'] = 'STOWED'
        elif kind == 'MESSAGE':
            body = short(c.get('body', ''), 800); require(body, 'الرسالة فارغة')
            s['messages'].append({'id': str(uuid4()), 'mission_id': m['id'], 'sender_id': actor['id'], 'name': actor['name'], 'role': role, 'body': body, 'at': now}); s['messages'] = s['messages'][-150:]
        event(s, kind, m['code'], actor, now)
    return s
