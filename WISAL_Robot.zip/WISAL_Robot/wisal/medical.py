"""Structured human observations and a separate educational NEWS2 Scale 1 calculator."""
import math
import time

RULE_VERSION = 'RCP-NEWS2-2017-SCALE1-WISAL-DEMO-2'
FIELDS = {
    'temperature': {'label': 'الحرارة', 'unit': '°C', 'min': 20, 'max': 50, 'decimal': True},
    'pulse': {'label': 'النبض', 'unit': 'bpm', 'min': 1, 'max': 300},
    'rr': {'label': 'معدل التنفس', 'unit': '/min', 'min': 1, 'max': 100},
    'spo2': {'label': 'تشبع الأكسجين', 'unit': '%', 'min': 1, 'max': 100},
    'sbp': {'label': 'الضغط الانقباضي', 'unit': 'mmHg', 'min': 1, 'max': 350},
}
SOURCES = [
    {'title': 'WHO–ICRC Basic Emergency Care', 'url': 'https://www.who.int/publications/i/item/9789241513081', 'use': 'تنظيم التقييم البشري والتسليم للمختص.'},
    {'title': 'RCUK The ABCDE Approach', 'url': 'https://www.resus.org.uk/library/abcde-approach', 'use': 'سلامة المشهد والانطباع العام وتوثيق ABCDE وإعادة التقييم.'},
    {'title': 'RCUK Adult Basic Life Support 2025', 'url': 'https://www.resus.org.uk/professional-library/2025-resuscitation-guidelines/adult-basic-life-support-guidelines', 'use': 'التصعيد المبكر عند عدم الاستجابة؛ لا انتظار للقياسات.'},
    {'title': 'RCP NEWS2 2017', 'url': 'https://www.rcp.ac.uk/resources/national-early-warning-score-news-2/', 'use': 'حاسبة تعليمية منفصلة مكتملة المدخلات، Scale 1 فقط.'},
    {'title': 'RCP additional implementation guidance', 'url': 'https://www.rcp.ac.uk/media/umzn4ntq/news2_additional-guidance-002-_0.pdf', 'use': 'حدود التطبيق والنتائج الناقصة؛ لا تحويل آلي لقرار فرز ميداني.'},
]

def timestamp():
    return int(time.time() * 1000)

def require(condition, message):
    if not condition:
        raise ValueError(message)

def short(value, maximum=600):
    require(isinstance(value, str) and len(value) <= maximum, 'نص غير صالح أو أطول من الحد')
    return value.strip()

def primary_observation(data, now=None):
    now = timestamp() if now is None else now
    p = {'saved_at': now, 'source': 'HUMAN_ENTERED_DEMO'}
    for key, allowed in {'scene': ['safe', 'unsafe', 'unknown'], 'response': ['A', 'V', 'P', 'U', 'unknown'], 'breathing': ['normal', 'abnormal', 'absent', 'unknown']}.items():
        p[key] = data.get(key, 'unknown')
        require(p[key] in allowed, 'قيمة غير صالحة للمشاهدة الأولية')
    for key in ['impression', 'airway', 'breathing_notes', 'circulation', 'disability', 'exposure']:
        p[key] = short(data.get(key, ''), 600)
    return p

def primary_alerts(p):
    if not p:
        return []
    result = []
    if p['scene'] == 'unsafe':
        result.append({'code': 'SCENE_UNSAFE', 'text': 'المشهد غير آمن وفق الإدخال؛ أوقفي الاقتراب واطلبي الدعم المناسب.'})
    if p['response'] == 'U':
        result.append({'code': 'UNRESPONSIVE', 'text': 'عدم استجابة: يلزم طلب الإسعاف أو المسعف فورًا، دون انتظار الحرارة والنبض أو اكتمال النموذج.'})
        if p['breathing'] in ['abnormal', 'absent']:
            result.append({'code': 'SUSPECTED_ARREST', 'text': 'اشتباه توقف قلب وفق المشاهدات المدخلة: عدم استجابة وتنفس غائب أو غير طبيعي. اتبعي توجيه المرسل الإسعافي فورًا؛ لا علاج آلي من وِصال.'})
    return result

def prepare_assessment(data, now=None):
    now = timestamp() if now is None else now
    a = {k: data.get(k) for k in ['age', 'pregnant', 'scale2', 'spinal', 'oxygen', 'consciousness']}
    require(a['age'] is None or type(a['age']) is int and 0 <= a['age'] <= 120, 'العمر غير صالح')
    for key in ['pregnant', 'scale2', 'spinal', 'oxygen']:
        require(a[key] is None or type(a[key]) is bool, 'قيمة أهلية غير صالحة')
    require(a['consciousness'] in [None, 'A', 'C', 'V', 'P', 'U'], 'حالة الوعي غير صالحة')
    for key, limit in [('complaint', 600), ('allergies', 400), ('history', 400), ('notes', 1200)]:
        a[key] = short(data.get(key, ''), limit)
    a.update({'saved_at': now, 'readings': {}, 'source': 'SIMULATED_ONLY'})
    for key, f in FIELDS.items():
        r = data.get('readings', {}).get(key, {})
        value = r.get('value')
        quality = r.get('quality', 'UNAVAILABLE' if value is None else 'SIMULATED')
        require(quality in ['UNAVAILABLE', 'SIMULATED', 'STALE', 'INVALID'], 'جودة قراءة غير صالحة')
        if value is not None:
            require(type(value) in [float, int] and math.isfinite(value) and f['min'] <= value <= f['max'], f"قيمة {f['label']} خارج عقد الإدخال")
            require(abs(value * 10 - round(value * 10)) < 1e-7 if f.get('decimal') else float(value).is_integer(), 'دقة إدخال غير صالحة')
        require(value is not None or quality != 'SIMULATED', 'يجب وسم القراءة المفقودة بأنها غير متوفرة')
        a['readings'][key] = {'value': value, 'quality': quality, 'unit': f['unit'], 'source': 'SIMULATED', 'measured_at': now}
    return a

def component_score(key, v):
    if key == 'rr': return 3 if v <= 8 else 1 if v <= 11 else 0 if v <= 20 else 2 if v <= 24 else 3
    if key == 'spo2': return 3 if v <= 91 else 2 if v <= 93 else 1 if v <= 95 else 0
    if key == 'sbp': return 3 if v <= 90 else 2 if v <= 100 else 1 if v <= 110 else 0 if v <= 219 else 3
    if key == 'pulse': return 3 if v <= 40 else 1 if v <= 50 else 0 if v <= 90 else 1 if v <= 110 else 2 if v <= 130 else 3
    if key == 'temperature': return 3 if v <= 35 else 1 if v <= 36 else 0 if v <= 38 else 1 if v <= 39 else 2
    raise ValueError('معامل غير معروف')

def news2(a, now=None):
    now = timestamp() if now is None else now
    missing, reasons, components = [], [], {}
    if not a:
        return {'complete': False, 'total': None, 'partial': 0, 'components': {}, 'missing': [f['label'] for f in FIELDS.values()], 'reasons': ['لم تحفظ القياسات بعد'], 'band': None, 'rule_version': RULE_VERSION}
    if a['age'] is None or a['age'] < 16: reasons.append('العمر غير معروف أو أقل من 16 سنة')
    for key, text in [('pregnant', 'الحمل خارج نطاق الحاسبة'), ('scale2', 'الحاجة إلى Scale 2 غير مدعومة'), ('spinal', 'حجب احترازي تقني عند إصابة الحبل الشوكي')]:
        if a[key] is None: reasons.append('أهلية الحساب غير مكتملة')
        elif a[key]: reasons.append(text)
    for key, f in FIELDS.items():
        r = a['readings'][key]
        if r['value'] is None or r['quality'] != 'SIMULATED' or not 0 <= now - r['measured_at'] <= 300000:
            missing.append(f['label'])
        else: components[key] = component_score(key, r['value'])
    if a['oxygen'] is None: missing.append('الأكسجين الإضافي')
    else: components['oxygen'] = 2 if a['oxygen'] else 0
    if a['consciousness'] is None: missing.append('الوعي')
    else: components['consciousness'] = 0 if a['consciousness'] == 'A' else 3
    partial = sum(components.values())
    complete = not reasons and not missing
    band = ('High' if partial >= 7 else 'Medium' if partial >= 5 else 'Single parameter 3' if 3 in components.values() else 'Low') if complete else None
    return {'complete': complete, 'total': partial if complete else None, 'partial': partial, 'components': components, 'missing': missing, 'reasons': list(dict.fromkeys(reasons)), 'band': band, 'rule_version': RULE_VERSION, 'review_required': True}

def demo_assessment(complete=False, now=None):
    data = {'age': 30, 'pregnant': False, 'scale2': False, 'spinal': False, 'oxygen': False if complete else None, 'consciousness': 'A' if complete else None,
            'complaint': 'حالة مصطنعة: أشعر بتعب وأطلب المساعدة.', 'allergies': 'غير معروف في السيناريو', 'history': 'لم يذكر في السيناريو', 'notes': 'قياسات مصطنعة للعرض', 'readings': {}}
    for k, v in {'temperature': 37.2, 'pulse': 96, 'rr': 18, 'spo2': 97, 'sbp': 118}.items():
        present = complete or k in ['temperature', 'pulse']
        data['readings'][k] = {'value': v if present else None, 'quality': 'SIMULATED' if present else 'UNAVAILABLE'}
    return prepare_assessment(data, now)
