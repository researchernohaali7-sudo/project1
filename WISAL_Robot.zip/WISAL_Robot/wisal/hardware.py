"""Integration boundary. Implementing real actuation is deliberately unsupported."""
class MockHardware:
    mode = 'SIMULATION'
    components = ['camera', 'proximity', 'lidar', 'display', 'medical_drawer', 'wheeled_base', 'battery', 'five_finger_arm']

    def real_command(self, *_args, **_kwargs):
        raise RuntimeError('Physical actuation is disabled. This package supplies simulation only.')
