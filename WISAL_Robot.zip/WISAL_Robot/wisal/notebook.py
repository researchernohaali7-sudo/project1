"""Interactive notebook frontend. No web server, public tunnel, GPU, or physical actuation."""
from pathlib import Path
import json
import html
from .store import Store, Conflict, Forbidden
from .domain import LABELS, LOCATIONS, ROLES, report_for
from .medical import FIELDS, news2, primary_alerts, timestamp


def safe(value): return html.escape(str(value if value is not None else ''))


class NotebookSession:
    """Same transactional engine as the web frontend; four explicitly simulated roles."""
    def __init__(self, directory='runtime_data/colab'):
        self.directory = Path(directory); self.store = Store(self.directory)
        self.credentials_path = self.directory / 'notebook_session.json'; self.role = 'operator'
        try:
            self.credentials = json.loads(self.credentials_path.read_text())
            self.read()
        except (OSError, ValueError, KeyError, Forbidden):
            self.new()

    def new(self):
        owner = self.store.create('التشغيل'); room, key = owner['room_id'], owner['join_key']
        self.credentials = {'operator': owner}
        for role, alias in [('robot', 'طرف وِصال'), ('medic', 'المسعف'), ('observer', 'متابعة الفريق')]:
            self.credentials[role] = {'room_id': room, **self.store.join(room, key, alias, role)}
        self.credentials_path.write_text(json.dumps(self.credentials, ensure_ascii=False))
        return self.read()

    def read(self):
        actor = self.credentials[self.role]
        return self.store.read(actor['room_id'], actor['member_id'], actor['member_token'])

    def mission(self):
        missions = self.read()['state']['missions']
        return next((m for m in missions if m['status'] not in ['CLOSED', 'CANCELLED']), missions[0] if missions else None)

    def do(self, kind, role=None, **extra):
        actor = self.credentials[role or self.role]
        command = {'type': kind, **extra}
        if 'id' not in command and self.mission(): command['id'] = self.mission()['id']
        for _ in range(3):
            revision = self.store.read(actor['room_id'], actor['member_id'], actor['member_token'])['revision']
            try: return self.store.mutate(actor['room_id'], actor['member_id'], actor['member_token'], revision, command)
            except Conflict: continue
        raise Conflict('تحديث متزامن؛ أعيدي المحاولة')

    def report(self):
        m = self.mission()
        if not m: raise ValueError('أنشئي بلاغًا أولًا')
        return {'report': m.get('handover') or report_for(m), 'review': m.get('review'), 'status': m['status']}

    def full_demo(self):
        """One explicitly synthetic walkthrough with role-specific authorization at every transition."""
        self.new()
        def act(kind, role='operator', **extra): self.do(kind, role, **extra)
        act('CREATE', location='gate3', description='بلاغ مصطنع: شخص يقظ يطلب المساعدة قرب البوابة الثالثة.')
        act('VERIFY_REPORT', confirmed=True); act('ASSIGN'); act('START_ROUTE')
        for _ in range(5): act('ADVANCE')
        act('SAVE_PRIMARY', 'robot', primary={'scene': 'safe', 'response': 'A', 'breathing': 'normal', 'impression': 'مشاهدة بشرية مصطنعة؛ الشخص يقظ ويطلب المساعدة.'})
        act('PERSON_CONFIRM', 'robot', confirmed=True)
        act('DEMO_READINGS', 'robot', complete=True)
        act('CARE_AUTHORIZE', 'medic', supervision=True, consent=True)
        act('DRAWER_OPEN', 'robot'); act('ARM_READY', 'robot'); act('ARM_ASSIST_DEMO', 'robot')
        act('ARM_STOW', 'robot'); act('DRAWER_CLOSE', 'robot')
        act('SEND_REPORT', 'robot'); act('REVIEW', 'medic', note='مراجعة مصطنعة للعرض: استُلمت البيانات التجريبية، دون اعتماد طبي أو تشغيل أجهزة.')
        act('RETURN')
        for _ in range(5): act('ADVANCE')
        self.role = 'operator'
        return self.report()


def report_html(result):
    r, review = result['report'], result['review']; p, a, n = r['primary'] or {}, r['assessment'] or {}, r['news2']
    rows = ''.join(f"<tr><td>{safe(f['label'])}</td><td>{safe(a.get('readings', {}).get(k, {}).get('value', 'غير متوفر'))} {safe(f['unit'])}</td><td>{safe(a.get('readings', {}).get(k, {}).get('quality', 'UNAVAILABLE'))}</td></tr>" for k, f in FIELDS.items())
    primary = ''.join(f'<p>{safe(x[0])}: {safe(p.get(x[1], "لم يوثق"))}</p>' for x in [('سلامة المشهد', 'scene'), ('الاستجابة', 'response'), ('التنفس', 'breathing'), ('الانطباع', 'impression'), ('A', 'airway'), ('B', 'breathing_notes'), ('C', 'circulation'), ('D', 'disability'), ('E', 'exposure')])
    alerts = ''.join(f'<p style="color:#a63e4e">{safe(x["text"])}</p>' for x in r['alerts'])
    score = f"{n['total']} · {safe(n['band'])}" if n['complete'] else 'غير مكتملة؛ ' + safe('، '.join(n['missing'] + n['reasons']))
    body = f'<h1>وِصال · تقرير تسليم تجريبي</h1><p>بيانات مصطنعة · الاعتماد الطبي لم يتم · {safe(r["mission_code"])}</p><p>الموقع: {safe(r["location"])} · الحالة: {safe(LABELS[result["status"]])}</p><h2>البلاغ والمشاهدة</h2><p>{safe(r["complaint"])}</p>{primary}{alerts}<h2>القياسات المصطنعة</h2><table><tr><th>القياس</th><th>القيمة</th><th>الجودة</th></tr>{rows}</table><h2>NEWS2 التعليمي · Scale 1</h2><p>{score}</p><p>لا تشخيص أو قرار فرز آلي من هذه النتيجة. الحرارة والنبض وحدهما لا ينتجان درجة كاملة.</p><h2>تسليم مختصر</h2><p>{safe(a.get("complaint", ""))}</p><p>الحساسية: {safe(a.get("allergies", "غير معروف"))} · التاريخ: {safe(a.get("history", "غير معروف"))}</p><p>{safe(a.get("notes", ""))}</p><h2>مراجعة دور المسعف</h2><p>{safe(review["note"]) if review else "بانتظار المراجعة"}</p><p>نسخة وقتية من بيانات المحاكاة؛ لا تثبت قياسات أجهزة أو اعتمادًا طبيًا.</p>'
    return '<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>WISAL Report</title><style>body{font:15px/1.9 Tahoma,Arial;color:#233d4d;max-width:850px;margin:40px auto;padding:25px}h1{font-size:26px}h2{font-size:19px;margin-top:30px}table{border-collapse:collapse;width:100%}td,th{border:1px solid #dce4ea;padding:10px;text-align:right}th{background:#eff4f7}p{white-space:pre-wrap}@media print{body{margin:0}}</style><body>'+body+'</body></html>'


class NotebookDashboard:
    def __init__(self, directory='runtime_data/colab'):
        import ipywidgets as w
        self.w = w; self.engine = NotebookSession(directory)
        self.container = w.VBox(); self.message = w.HTML(); self.tab_index = 0
        self._render()

    def display(self):
        from IPython.display import display
        display(self.container)
        return self

    def _notice(self, text, error=False):
        self.message.value = f'<div dir="rtl" style="padding:12px;border-radius:8px;background:{"#ffedf0" if error else "#eaf5f3"};color:{"#9c3c4f" if error else "#287770"}">{safe(text)}</div>'

    def _b(self, text, callback, style='', refresh=True):
        b = self.w.Button(description=text, button_style=style, layout=self.w.Layout(width='auto', min_width='155px', margin='5px'))
        def click(_):
            try:
                callback(); self._notice('تم تنفيذ الإجراء.');
                if refresh: self._render()
            except Exception as exc: self._notice(str(exc), True)
        b.on_click(click); return b

    def _command(self, text, kind, style='', **extra):
        return self._b(text, lambda: self.engine.do(kind, **extra), style)

    def _row(self, *children): return self.w.HBox(list(children), layout=self.w.Layout(flex_flow='row wrap', align_items='center'))
    def _text(self, label, value='', area=False):
        w = self.w.Textarea if area else self.w.Text
        return w(description=label, value=value or '', style={'description_width': '135px'}, layout=self.w.Layout(width='97%'))
    def _select(self, label, choices, value):
        return self.w.Dropdown(description=label, options=choices, value=value, style={'description_width': '135px'}, layout=self.w.Layout(width='97%'))
    def _html(self, text): return self.w.HTML('<div dir="rtl" style="font:14px/1.9 Tahoma,Arial;color:#294656;padding:8px">'+text+'</div>')

    def _render(self):
        w = self.w; state = self.engine.read()['state']; m = self.engine.mission(); r = state['robot']
        role = self._select('دور العرض', [(label,key) for key,label in ROLES.items()], self.engine.role)
        role.observe(self._role, names='value')
        top = self._html('<div style="background:#1d3544;color:white;padding:24px;border-radius:12px"><b style="font-size:27px">وِصال · WISAL</b><p>روبوت الاستجابة الأولية الأرضي · محاكاة تفاعلية داخل النوتبوك</p><span style="color:#9fced5">الكاميرا · LiDAR والقرب · شاشة · عجلات وبطارية · درج جانبي · ذراع بخمس أصابع</span></div><p>الأدوار هنا مصطنعة للتجربة على جهاز تشغيل واحد. القرار الطبي للمختص، والربط الفيزيائي معطل.</p>')
        controls = self._row(role, self._b('رحلة عرض كاملة مصطنعة', self.engine.full_demo, 'success'), self._b('جلسة جديدة', self.engine.new), self._command('توقف محاكى', 'STOP', 'danger'))
        tabs = w.Tab(children=[self._ops(m,r), self._assessment(m), self._robot(m,r), self._vision(), self._report(m)])
        for i,t in enumerate(['البلاغ والمسار','التقييم الأولي','الدرج والذراع','الرؤية الاختيارية','التقرير والدليل']): tabs.set_title(i,t)
        tabs.selected_index = self.tab_index
        tabs.observe(lambda change: setattr(self,'tab_index',change['new']), names='selected_index')
        self.container.children = (top, controls, self.message, tabs)

    def _role(self, change): self.engine.role = change['new']; self._render()

    def _ops(self, m, r):
        w=self.w
        location=self._select('الموقع', [(v,k) for k,v in LOCATIONS.items()], 'gate3')
        description=self._text('وصف مصطنع', 'شخص يطلب المساعدة قرب البوابة الثالثة.', True)
        box=[self._html('<h3>١ · بلاغ وتحقق ثم تكليف</h3>'),location,description,self._b('إضافة بلاغ',lambda:self.engine.do('CREATE',location=location.value,description=description.value),'primary')]
        if m:
            progress=m['return_progress'] if m['status']=='RETURNING' else m['progress']
            box += [self._html(f'<h3>{safe(m["code"])} · {safe(LABELS[m["status"]])}</h3><p>{safe(m["description"])}</p><p>البطارية: {r["battery"]}% · الرابط: {"متصل" if r["link"] else "مفصول"} · العائق: {"موجود" if r["obstacle"] else "غير موجود"}</p>'),w.IntProgress(value=progress,min=0,max=100,description='المسار'), self._row(self._command('تحقق بشري من البلاغ','VERIFY_REPORT',confirmed=True),self._command('تكليف وِصال','ASSIGN'),self._command('بدء المسار','START_ROUTE'),self._command('تقدم خطوة 20%','ADVANCE','primary'),self._command('استئناف صريح','RESUME'))]
        box += [self._html('<h3>٢ · جربي أسباب التوقف</h3><p>إزالة العائق أو عودة الرابط لا تعيدان الحركة تلقائيًا. استخدمي الاستئناف الصريح بعد معالجة السبب.</p>'),self._row(self._command('إزالة العائق' if r['obstacle'] else 'إضافة عائق','ROBOT',key='obstacle',value=not r['obstacle']),self._command('إعادة الرابط' if not r['link'] else 'قطع الرابط','ROBOT',key='link',value=not r['link']),self._command('فك التوقف المحاكى','ROBOT',key='estop',value=False)),self._html('<p>المسار ومواقع الفعالية مصطنعة. لا توجد قيادة لمحركات أو ملاحة LiDAR حقيقية.</p>')]
        if m: box += [self._html('<h3>سجل آخر الأحداث</h3>'+''.join('<p>• '+safe(e['kind'])+' · '+safe(e['actor'])+'</p>' for e in self.engine.read()['state']['events'][-8:]))]
        return w.VBox(box)

    def _assessment(self, m):
        w=self.w
        if not m: return self._html('أنشئي بلاغًا من تبويب البلاغ والمسار أولًا.')
        p=m['primary'] or {}; a=m['assessment'] or {}
        scene=self._select('سلامة المشهد',[('غير معروف','unknown'),('آمن وفق المشاهدة','safe'),('غير آمن','unsafe')],p.get('scene','unknown'))
        response=self._select('الاستجابة AVPU',[('لم تقيم','unknown'),('يقظ A','A'),('للصوت V','V'),('للألم · إدخال المختص P','P'),('لا يستجيب U','U')],p.get('response','unknown'))
        breathing=self._select('التنفس',[('لم يقيم','unknown'),('طبيعي وفق المشاهدة','normal'),('غير طبيعي','abnormal'),('غائب','absent')],p.get('breathing','unknown'))
        live=w.HTML()
        def early(_=None):
            alerts=primary_alerts({'scene':scene.value,'response':response.value,'breathing':breathing.value})
            live.value='<div dir="rtl" style="background:#ffedf0;color:#a63b4e;padding:12px">'+''.join('<p>'+safe(x['text'])+'</p>' for x in alerts)+'</div>' if alerts else ''
        for control in [scene,response,breathing]: control.observe(early,names='value')
        early()
        notes={k:self._text(label,p.get(k,''),True) for k,label in [('impression','الانطباع العام'),('airway','A · مجرى الهواء'),('breathing_notes','B · التنفس'),('circulation','C · الدورة والنزف'),('disability','D · الوعي'),('exposure','E · البيئة') ]}
        def primary(): self.engine.do('SAVE_PRIMARY',base_primary_saved_at=p.get('saved_at'),primary={'scene':scene.value,'response':response.value,'breathing':breathing.value,**{k:v.value for k,v in notes.items()}})
        age=self._text('العمر',str(a.get('age') if a.get('age') is not None else ''))
        tri=[('غير معروف',None),('لا',False),('نعم',True)]
        flags={k:self._select(label,tri,a.get(k)) for k,label in [('oxygen','أكسجين إضافي'),('pregnant','حمل معروف'),('scale2','طلب Scale 2'),('spinal','إصابة حبل شوكي')]}
        consciousness=self._select('الوعي ACVPU',[('غير معروف',None),('يقظ','A'),('تشوش جديد','C'),('للصوت','V'),('للألم','P'),('دون استجابة','U')],a.get('consciousness'))
        values={k:self._text(f['label']+' '+f['unit'],str(a.get('readings',{}).get(k,{}).get('value') if a.get('readings',{}).get(k,{}).get('value') is not None else '')) for k,f in FIELDS.items()}
        qualities={k:self._select('الجودة',[(v,k) for k,v in [('UNAVAILABLE','غير متوفرة'),('SIMULATED','مصطنعة'),('STALE','قديمة'),('INVALID','غير صالحة')]],a.get('readings',{}).get(k,{}).get('quality','UNAVAILABLE')) for k in FIELDS}
        texts={k:self._text(label,a.get(k,''),True) for k,label in [('complaint','الشكوى'),('allergies','الحساسية'),('history','تاريخ مختصر'),('notes','ملاحظات التسليم')]}
        base_saved_at=a.get('saved_at')
        def save_assessment():
            payload={k:v.value for k,v in flags.items()}; payload['age']=int(age.value) if age.value.strip() else None; payload['consciousness']=consciousness.value
            payload.update({k:v.value for k,v in texts.items()}); payload['readings']={k:{'value':float(v.value) if v.value.strip() else None,'quality':qualities[k].value} for k,v in values.items()}
            self.engine.do('SAVE_ASSESSMENT',assessment=payload,base_saved_at=base_saved_at)
        score=news2(a if a else None)
        score_text=str(score['total'])+' · '+str(score['band']) if score['complete'] else 'غير مكتملة؛ المفقود: '+ '، '.join(score['missing']+score['reasons'])
        read_widgets=[]
        for k in FIELDS: read_widgets.extend([values[k],qualities[k]])
        return w.VBox([self._html('<h3>ابدئي بسلامة المشهد والانطباع العام ثم الاستجابة والتنفس</h3><p>عدم الاستجابة: تصعيد فوري دون انتظار القياسات. هذا النموذج لا يجري اتصالًا خارجيًا بالإسعاف.</p>'),scene,response,breathing,live,*notes.values(),self._row(self._b('حفظ المشاهدة',primary,'primary'),self._command('إشعار داخلي عاجل','ESCALATE','danger',reason='طلب مراجعة فورية')),self._html('<h3>القياسات المصطنعة · متاحة بعد الوصول</h3>'),self._row(self._command('حرارة ونبض فقط','DEMO_READINGS',complete=False),self._command('مثال مكتمل للحاسبة','DEMO_READINGS',complete=True)),age,*flags.values(),consciousness,*read_widgets,*texts.values(),self._b('حفظ التقييم',save_assessment,'primary'),self._html('<h3>NEWS2 التعليمي · Scale 1: '+safe(score_text)+'</h3><p>حساب منفصل، لا تشخيص أو فرز آلي. الحرارة والنبض وحدهما لا يكفيان. حجب القراءة بعد خمس دقائق حد تقني للعرض.</p>')])

    def _robot(self,m,r):
        w=self.w
        from IPython.display import SVG
        scene=m.get('primary',{}).get('scene') if m else None
        supervision=w.Checkbox(description='إشراف مباشر في السيناريو',indent=False)
        consent=w.Checkbox(description='موافقة موثقة في السيناريو',indent=False)
        state=self._html(f'<h3>درج المستلزمات: {safe(r["drawer"])} · الذراع: {safe(r["arm"])}</h3><p>سلامة المشهد: {safe(scene or "لم توثق")} · التحقق البشري من الشخص: {"موثق" if r["person_confirmed"] else "لم يوثق"}</p><p>شاش ولاصق ومستلزمات غير دوائية يحددها الفريق الطبي. الذراع بخمس أصابع حالات افتراضية فقط؛ لا تحكم بقوة ضغط.</p>')
        image_path=Path(__file__).parent/'web/assets/robot.svg'
        image=w.HTML(image_path.read_text().replace('<svg ','<svg style="max-width:300px;width:100%" ',1))
        ref=Path(__file__).parent/'web/assets/robot-reference.png'
        reference=w.Accordion(children=[w.Image(value=ref.read_bytes(),format='png',layout=w.Layout(width='420px'))])
        reference.set_title(0,'عرض الصورة المرجعية للتصميم'); reference.selected_index=None
        return w.VBox([image,state,self._command('تحقق بشري من الشخص','PERSON_CONFIRM',confirmed=True),self._html('<h3>تصريح دور المسعف في المحاكاة</h3><p>اختاري دور المسعف أعلى اللوحة قبل التصريح، ثم دور التشغيل أو طرف وِصال للتجربة. تعديل المشاهدة أو القياسات أو التوقف يلغي التصريح السابق.</p>'),supervision,consent,self._b('إصدار تصريح تجريبي',lambda:self.engine.do('CARE_AUTHORIZE',supervision=supervision.value,consent=consent.value),'primary'),self._row(self._command('فتح الدرج','DRAWER_OPEN'),self._command('إغلاق الدرج','DRAWER_CLOSE'),self._command('تجهيز الذراع','ARM_READY'),self._command('وضع مساعدة محاكى','ARM_ASSIST_DEMO'),self._command('تخزين الذراع','ARM_STOW')),self._html('<p>الحركة محجوبة إذا كان الدرج مفتوحًا أو الذراع خارج التخزين. أوامر الأجهزة الحقيقية غير متاحة.</p>'),reference])

    def _vision(self):
        w=self.w; upload=w.FileUpload(accept='image/png,image/jpeg,image/webp',multiple=False); result=w.Output()
        def detect():
            if not upload.value: raise ValueError('اختاري صورة تجريبية أولًا')
            from .vision import detect_person
            import cv2
            import numpy as np
            item=next(iter(upload.value.values())) if isinstance(upload.value,dict) else upload.value[0]
            raw=bytes(item['content']); detection=detect_person(raw)
            image=cv2.imdecode(np.frombuffer(raw,np.uint8),cv2.IMREAD_COLOR)
            for b in detection['boxes']: cv2.rectangle(image,(b['x'],b['y']),(b['x']+b['width'],b['y']+b['height']),(150,230,70),3)
            encoded=cv2.imencode('.jpg',image)[1].tobytes()
            from IPython.display import display, Image
            with result:
                result.clear_output(wait=True);display(Image(data=encoded,width=640));display(self._html(f'عدد الأشكال المحتملة: {len(detection["boxes"])}. {safe(detection["limits"])}'))
        return w.VBox([self._html('<h3>رؤية اختيارية للصورة · OpenCV HOG/SVM</h3><p>فعّلي ENABLE_VISION في خلية الإعداد ثم شغليها إن لم تكن الحزمة مثبتة. الخوارزمية قد تفوّت الشخص المستلقي أو المحجوب؛ لا تستنتج حالة طبية أو هوية. عدم الكشف لا ينفي وجود شخص.</p>'),upload,self._b('تحليل الصورة',detect,'primary',refresh=False),result])

    def _report(self,m):
        w=self.w; review=self._text('ملاحظة المسعف','استُلمت بيانات السيناريو التجريبي؛ دون اعتماد طبي.',True)
        output=w.Output()
        def show():
            from IPython.display import display,HTML
            with output: output.clear_output(wait=True);display(HTML(report_html(self.engine.report())))
        def export():
            from IPython.display import display,FileLink
            directory=self.engine.directory/'exports'; directory.mkdir(exist_ok=True)
            result=self.engine.report(); json_path=directory/'WISAL_Report.json'; html_path=directory/'WISAL_Report.html'
            json_path.write_text(json.dumps(result,ensure_ascii=False,indent=2)); html_path.write_text(report_html(result))
            with output:
                output.clear_output(wait=True)
                try:
                    from google.colab import files
                    files.download(str(html_path)); files.download(str(json_path))
                    display(self._html('أُرسل ملف HTML وJSON للتنزيل. افتحي HTML في المتصفح ثم طباعة ← حفظ PDF.'))
                except ImportError:
                    display(FileLink(str(html_path)));display(FileLink(str(json_path)))
        return w.VBox([self._html('<h3>تسليم منظم ومراجعة ثم عودة</h3><p>١. أرسلي التقرير بعد حفظ التقييم. ٢. اختاري دور المسعف لتسجيل المراجعة. ٣. اختاري المشغلة، أغلقي الدرج وخزني الذراع ثم ابدئي العودة. ٤. تقدمي خمس خطوات في تبويب المسار حتى إغلاق المهمة.</p>'),self._command('إرسال التقرير للمسعف','SEND_REPORT','primary'),review,self._b('تسجيل مراجعة المسعف',lambda:self.engine.do('REVIEW',note=review.value),'success'),self._command('بدء العودة للقاعدة','RETURN'),self._row(self._b('عرض التقرير',show,refresh=False),self._b('تنزيل تقرير HTML وJSON',export,refresh=False)),output,self._html('<h3>أين جلسة الفريق؟</h3><p>Colab يشغل تجربة تفاعلية واحدة داخل النوتبوك. تبديل الأدوار شرح للمهام؛ ليس اتصالًا بين أشخاص حقيقيين. جلسة المتصفح المشتركة والرسائل والصوت والصورة ضمن نسخة المشروع التي تعمل على Python محليًا أو Codespaces.</p><p>لا يحتاج التشغيل GPU. عند انقطاع Colab أعيدي Run all؛ الملفات ضمن جلسة Colab مؤقتة. يمكن حفظ runtime_data في Drive من خلية الإعداد الاختيارية دون رفعه للمستودع.</p>')])
