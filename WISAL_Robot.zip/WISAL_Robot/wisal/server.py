"""Local/shared demonstration server; real hardware remains disabled."""
import asyncio
from contextlib import asynccontextmanager
import json
import os
from pathlib import Path
import re
import tempfile
import time
from uuid import uuid4
from fastapi import FastAPI, Request, UploadFile, File
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from .store import Store, Conflict, Forbidden
from .domain import report_for, LABELS, ROLES, LOCATIONS
from .medical import FIELDS, SOURCES, timestamp, news2

WEB = Path(__file__).parent / 'web'

class Media:
    def __init__(self, root): self.root = Path(root); self.root.mkdir(parents=True, exist_ok=True)
    def cleanup(self):
        for p in self.root.glob('*/*.bin'):
            try:
                if time.time() - p.stat().st_mtime > 25:
                    p.unlink(missing_ok=True); p.with_suffix('.type').unlink(missing_ok=True)
            except FileNotFoundError: pass
    def clear(self, call_id):
        directory = self.root / call_id
        if directory.exists():
            for p in directory.iterdir(): p.unlink(missing_ok=True)
            try: directory.rmdir()
            except OSError: pass
    def put(self, call_id, sender, data, mime):
        self.cleanup(); directory = self.root / call_id; directory.mkdir(exist_ok=True)
        clip = f'{timestamp()}-{sender}-{uuid4()}.bin'; path = directory / clip
        path.write_bytes(data); path.with_suffix('.type').write_text(mime)
        files = sorted(directory.glob('*'+sender+'*.bin'), reverse=True)
        for old in files[4:]: old.unlink(missing_ok=True); old.with_suffix('.type').unlink(missing_ok=True)
        return clip
    def list(self, call_id, sender):
        self.cleanup(); return [{'id': p.name, 'at': int(p.name.split('-')[0])} for p in sorted((self.root / call_id).glob('*'+sender+'*.bin')) if time.time() - p.stat().st_mtime <= 20][-3:]
    def get(self, call_id, sender, clip):
        self.cleanup()
        if not re.fullmatch(r'[0-9]{13}-[a-zA-Z0-9-]{73}\.bin', clip) or ('-'+sender+'-') not in clip: raise ValueError('مقطع غير صالح')
        path = self.root / call_id / clip
        if not path.is_file() or time.time() - path.stat().st_mtime > 20: raise FileNotFoundError
        return path, path.with_suffix('.type').read_text()


def create_app(directory=None):
    directory = directory or os.environ.get('WISAL_DATA_DIR', 'runtime_data')
    store = Store(directory)
    media = Media(Path(directory) / 'media')
    @asynccontextmanager
    async def lifespan(app):
        async def clean():
            while True:
                media.cleanup(); await asyncio.sleep(10)
        task = asyncio.create_task(clean())
        try: yield
        finally:
            task.cancel()
            for p in media.root.glob('*'): media.clear(p.name)
    app = FastAPI(title='WISAL Ground Robot', version='4.0.0', lifespan=lifespan)
    app.state.store = store; app.state.media = media
    @app.middleware('http')
    async def protect(request, call_next):
        if request.method not in ['GET', 'HEAD', 'OPTIONS']:
            origin = request.headers.get('origin')
            if origin:
                from urllib.parse import urlparse
                own_hosts = {request.headers.get('host', ''), request.headers.get('x-forwarded-host', '')}
                if urlparse(origin).netloc not in own_hosts:
                    return JSONResponse({'error': 'مصدر طلب غير مسموح'}, status_code=403)
            if int(request.headers.get('content-length', '0')) > 7 * 1024 * 1024:
                return JSONResponse({'error': 'الطلب أكبر من الحد'}, status_code=413)
        try: response = await call_next(request)
        except Exception:
            return JSONResponse({'error': 'تعذر تنفيذ الطلب'}, status_code=500)
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'no-referrer'
        response.headers['Cache-Control'] = 'no-store'
        return response
    @app.exception_handler(ValueError)
    async def bad(_request, exc): return JSONResponse({'error': str(exc)}, status_code=400)
    @app.exception_handler(Conflict)
    async def conflict(_request, exc): return JSONResponse({'error': str(exc)}, status_code=409)
    @app.exception_handler(Forbidden)
    async def forbidden(_request, exc): return JSONResponse({'error': str(exc)}, status_code=403)
    def identity(request):
        return request.headers.get('x-wisal-member', ''), request.headers.get('x-wisal-token', '')
    def envelope(result):
        return {**result, 'calculations': {m['id']: news2(m.get('assessment')) for m in result['state']['missions']}}
    def room_state(request, room_id): return envelope(store.read(room_id, *identity(request)))
    @app.get('/api/config')
    def config(): return {'labels': LABELS, 'roles': ROLES, 'locations': LOCATIONS, 'fields': FIELDS, 'sources': SOURCES, 'mode': 'SIMULATION', 'hardware_enabled': False}
    @app.get('/api/health')
    def health(): return {'ok': True, 'version': '4.0.0', 'mode': 'SIMULATION'}
    @app.post('/api/rooms')
    async def room(request: Request):
        body = await request.json(); result = store.create(body.get('name', ''))
        return {**result, **envelope(store.read(result['room_id'], result['member_id'], result['member_token']))}
    @app.post('/api/rooms/{room_id}/join')
    async def join(room_id: str, request: Request):
        body = await request.json(); result = store.join(room_id, body.get('join_key', ''), body.get('name', ''), body.get('role', 'observer'))
        return {**result, 'room_id': room_id, **envelope(store.read(room_id, result['member_id'], result['member_token']))}
    @app.get('/api/rooms/{room_id}')
    def read(room_id: str, request: Request): return room_state(request, room_id)
    @app.post('/api/rooms/{room_id}/actions')
    async def action(room_id: str, request: Request):
        raw = await request.body()
        if len(raw) > 50000: return JSONResponse({'error': 'الطلب أكبر من الحد'}, status_code=413)
        body = json.loads(raw)
        result = store.mutate(room_id, *identity(request), body.get('revision'), body.get('command', {}))
        if body.get('command', {}).get('type') == 'CALL_END': media.clear(body['command']['call_id'])
        return envelope(result)
    @app.get('/api/rooms/{room_id}/reports/{mission_id}')
    def report(room_id: str, mission_id: str, request: Request):
        state = room_state(request, room_id)['state']; m = next((m for m in state['missions'] if m['id'] == mission_id), None)
        if m is None: return JSONResponse({'error': 'المهمة غير موجودة'}, status_code=404)
        return {'report': m.get('handover') or report_for(m), 'review': m.get('review'), 'status': m['status']}
    @app.delete('/api/rooms/{room_id}')
    def delete(room_id: str, request: Request):
        state = room_state(request, room_id)['state']; store.delete(room_id, *identity(request))
        for call in state['calls']: media.clear(call['id'])
        return {'deleted': True}
    def call_access(request, room_id, call_id, allow_ended=False):
        member_id, _ = identity(request); state = room_state(request, room_id)['state']
        call = next((c for c in state['calls'] if c['id'] == call_id), None)
        if not call or member_id not in [call['from'], call['to']]: raise Forbidden('المكالمة غير متاحة لهذا الطرف')
        if not allow_ended and (call['status'] != 'connected' or timestamp() - call['updated_at'] > 90000): raise Conflict('المكالمة غير متصلة')
        other = call['to'] if call['from'] == member_id else call['from']
        return member_id, other
    @app.post('/api/rooms/{room_id}/media/{call_id}')
    async def upload_media(room_id: str, call_id: str, request: Request):
        sender, _ = call_access(request, room_id, call_id)
        mime = request.headers.get('content-type', '')
        if not re.fullmatch(r'(audio|video)/(webm|mp4|ogg)(;[a-zA-Z0-9=,. -]+)?', mime): return JSONResponse({'error': 'صيغة غير مدعومة'}, status_code=415)
        data = await request.body()
        if not 1 <= len(data) <= 256 * 1024: return JSONResponse({'error': 'حجم مقطع غير صالح'}, status_code=413)
        clip = media.put(call_id, sender, data, mime)
        return {'id': clip, 'bytes': len(data)}
    @app.get('/api/rooms/{room_id}/media/{call_id}')
    def media_list(room_id: str, call_id: str, request: Request):
        _, other = call_access(request, room_id, call_id); return {'clips': media.list(call_id, other)}
    @app.get('/api/rooms/{room_id}/media/{call_id}/{clip}')
    def media_get(room_id: str, call_id: str, clip: str, request: Request):
        _, other = call_access(request, room_id, call_id)
        try: path, mime = media.get(call_id, other, clip)
        except FileNotFoundError: return JSONResponse({'error': 'انتهى المقطع'}, status_code=404)
        return FileResponse(path, media_type=mime)
    @app.post('/api/rooms/{room_id}/vision')
    async def vision(room_id: str, request: Request, image: UploadFile = File(...)):
        actor = store.authenticate(room_id, *identity(request))
        if actor['role'] == 'observer': raise Forbidden('التحليل لدور تشغيل في العرض')
        data = await image.read(6 * 1024 * 1024 + 1)
        from .vision import detect_person
        try: return await asyncio.to_thread(detect_person, data)
        except ImportError: return JSONResponse({'error': 'الرؤية الاختيارية غير مثبتة؛ اتبعي دليل التفعيل'}, status_code=503)
    @app.get('/')
    def index(): return FileResponse(WEB / 'index.html', media_type='text/html')
    app.mount('/static', StaticFiles(directory=WEB), name='static')
    return app

app = create_app()
