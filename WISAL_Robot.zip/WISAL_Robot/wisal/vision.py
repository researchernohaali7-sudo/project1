"""Optional conventional HOG/SVM person detector. No identity or medical inference."""

def detect_person(data):
    import cv2
    import numpy as np
    if len(data) > 6 * 1024 * 1024: raise ValueError('الصورة أكبر من 6 ميغابايت')
    image = cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)
    if image is None: raise ValueError('الصورة غير قابلة للقراءة')
    h, w = image.shape[:2]
    if h * w > 12_000_000: raise ValueError('الصورة تتجاوز حد الأبعاد')
    scale = min(1.0, 800 / max(w, h))
    small = cv2.resize(image, (max(1, round(w * scale)), max(1, round(h * scale))))
    boxes = []
    if small.shape[0] >= 128 and small.shape[1] >= 64:
        detector = cv2.HOGDescriptor(); detector.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
        rects, _weights = detector.detectMultiScale(small, winStride=(8, 8), padding=(8, 8), scale=1.05)
        boxes = [{'x': round(int(x) / scale), 'y': round(int(y) / scale), 'width': round(int(bw) / scale), 'height': round(int(bh) / scale)} for x, y, bw, bh in rects]
    return {'model': 'OpenCV HOG + linear SVM', 'boxes': boxes, 'image_width': w, 'image_height': h,
            'human_verification_required': True, 'stored_image': False, 'medical_inference': False,
            'limits': 'مصنف تجريبي للأشخاص، وقد يفشل خصوصًا مع الاستلقاء أو الحجب. عدم الكشف لا ينفي وجود مصاب.'}
