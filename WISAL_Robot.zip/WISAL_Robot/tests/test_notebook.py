import tempfile
import unittest
from wisal.notebook import NotebookSession,NotebookDashboard,report_html

class NotebookTests(unittest.TestCase):
    def test_full_demo_and_resumption(self):
        with tempfile.TemporaryDirectory() as d:
            first=NotebookSession(d);result=first.full_demo();room=first.credentials['operator']['room_id']
            self.assertEqual(result['status'],'CLOSED');self.assertEqual(result['report']['news2']['total'],1);self.assertIsNotNone(result['review'])
            second=NotebookSession(d);self.assertEqual(second.credentials['operator']['room_id'],room);self.assertEqual(second.mission()['status'],'CLOSED')
    def test_notebook_roles_enforced(self):
        with tempfile.TemporaryDirectory() as d:
            session=NotebookSession(d);session.role='observer'
            with self.assertRaises(ValueError):session.do('CREATE',location='gate3',description='حالة')
    def test_widgets_build_without_web_server(self):
        try:import ipywidgets
        except ImportError:self.skipTest('optional notebook widgets not installed')
        with tempfile.TemporaryDirectory() as d:
            dashboard=NotebookDashboard(d);self.assertEqual(len(dashboard.container.children),4);dashboard.engine.full_demo();dashboard._render();self.assertEqual(dashboard.container.children[-1].titles[-1],'التقرير والدليل')
    def test_optional_real_image_decoder(self):
        try:import cv2,numpy as np
        except ImportError:self.skipTest('optional vision not installed')
        from wisal.vision import detect_person
        raw=cv2.imencode('.png',np.zeros((128,64,3),dtype=np.uint8))[1].tobytes();result=detect_person(raw)
        self.assertEqual(result['boxes'],[]);self.assertFalse(result['stored_image']);self.assertTrue(result['human_verification_required'])
