from copy import deepcopy
import unittest
from wisal.medical import *

class MedicalTests(unittest.TestCase):
    def test_scale_one_published_boundaries(self):
        cases={'rr':[(1,3),(8,3),(9,1),(11,1),(12,0),(20,0),(21,2),(24,2),(25,3)],'spo2':[(91,3),(92,2),(93,2),(94,1),(95,1),(96,0),(100,0)],'sbp':[(90,3),(91,2),(100,2),(101,1),(110,1),(111,0),(219,0),(220,3)],'pulse':[(40,3),(41,1),(50,1),(51,0),(90,0),(91,1),(110,1),(111,2),(130,2),(131,3)],'temperature':[(35,3),(35.1,1),(36,1),(36.1,0),(38,0),(38.1,1),(39,1),(39.1,2)]}
        for key,entries in cases.items():
            for value,expected in entries:
                with self.subTest(key=key,value=value): self.assertEqual(component_score(key,value),expected)
    def test_partial_temperature_and_pulse_never_full(self):
        n=news2(demo_assessment(False,1000),1001)
        self.assertFalse(n['complete']);self.assertIsNone(n['total']);self.assertIn('معدل التنفس',n['missing'])
    def test_complete_demo_is_one(self):
        n=news2(demo_assessment(True,1000),1001)
        self.assertTrue(n['complete']);self.assertEqual(n['total'],1);self.assertEqual(n['band'],'Low')
    def test_quality_and_age_gate(self):
        for quality in ['UNAVAILABLE','STALE','INVALID']:
            a=demo_assessment(True,1000);a['readings']['rr']['quality']=quality
            self.assertFalse(news2(a,1001)['complete'])
        for age in [None,15]:
            a=demo_assessment(True,1000);a['age']=age;self.assertIsNone(news2(a,1001)['total'])
        a=demo_assessment(True,1000);a['age']=16;self.assertTrue(news2(a,1001)['complete'])
    def test_eligibility_never_assumed(self):
        for key in ['pregnant','scale2','spinal']:
            for value in [None,True]:
                a=demo_assessment(True,1000);a[key]=value;self.assertFalse(news2(a,1001)['complete'])
    def test_stale_or_future_reading_blocks(self):
        self.assertFalse(news2(demo_assessment(True,1000),301001)['complete'])
        self.assertFalse(news2(demo_assessment(True,1000),999)['complete'])
        self.assertTrue(news2(demo_assessment(True,1000),301000)['complete'])
    def test_missing_oxygen_or_awareness(self):
        for key in ['oxygen','consciousness']:
            a=demo_assessment(True,1000);a[key]=None;self.assertFalse(news2(a,1001)['complete'])
    def test_invalid_numeric_contract(self):
        for value in [True,float('nan'),float('inf'),-1,301,90.5,'96']:
            with self.subTest(value=value),self.assertRaises(ValueError): prepare_assessment({'readings':{'pulse':{'value':value}}})
        with self.assertRaises(ValueError):prepare_assessment({'readings':{'temperature':{'value':37.25}}})
    def test_no_fabricated_readings(self):
        a=prepare_assessment({});self.assertTrue(all(r['value'] is None and r['quality']=='UNAVAILABLE' for r in a['readings'].values()))
        with self.assertRaises(ValueError):prepare_assessment({'readings':{'rr':{'quality':'SIMULATED','value':None}}})
    def test_escalation_without_vitals(self):
        p=primary_observation({'response':'U','breathing':'absent'})
        self.assertEqual({a['code'] for a in primary_alerts(p)},{'UNRESPONSIVE','SUSPECTED_ARREST'})
        self.assertEqual(primary_alerts(primary_observation({'response':'U','breathing':'normal'}))[0]['code'],'UNRESPONSIVE')
    def test_input_html_is_not_executed_in_report(self):
        from wisal.notebook import report_html
        from wisal.domain import report_for
        m={'code':'W-001','location':'gate3','description':'<script>alert(1)</script>','primary':{},'assessment':None}
        doc=report_html({'report':report_for(m),'review':None,'status':'NEW'})
        self.assertNotIn('<script>',doc);self.assertIn('&lt;script&gt;',doc)
