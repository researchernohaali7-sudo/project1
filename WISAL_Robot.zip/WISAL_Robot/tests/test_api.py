import os
from pathlib import Path
import tempfile
import threading
import time
import unittest
from concurrent.futures import ThreadPoolExecutor
from fastapi.testclient import TestClient
from wisal.server import create_app,Media
from wisal.store import Store,Conflict
from wisal.medical import timestamp

class ApiTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.app=create_app(self.tmp.name);self.ctx=TestClient(self.app);self.client=self.ctx.__enter__()
        r=self.client.post('/api/rooms',json={'name':'التشغيل'});self.assertEqual(r.status_code,200);self.owner=r.json();self.room=self.owner['room_id'];self.h=self.headers(self.owner)
    def tearDown(self):self.ctx.__exit__(None,None,None);self.tmp.cleanup()
    def headers(self,member):return {'x-wisal-member':member['member_id'],'x-wisal-token':member['member_token']}
    def join(self,role='medic'):
        return self.client.post(f'/api/rooms/{self.room}/join',json={'join_key':self.owner['join_key'],'name':role,'role':role}).json()
    def read(self):return self.client.get(f'/api/rooms/{self.room}',headers=self.h).json()
    def action(self,kind,member=None,**extra):
        headers=self.headers(member) if member else self.h;latest=self.client.get(f'/api/rooms/{self.room}',headers=headers).json()
        return self.client.post(f'/api/rooms/{self.room}/actions',headers=headers,json={'revision':latest['revision'],'command':{'type':kind,**extra}})
    def test_authentication_required_and_room_scoped(self):
        self.assertEqual(self.client.get(f'/api/rooms/{self.room}').status_code,403)
        other=self.client.post('/api/rooms',json={'name':'غرفة أخرى'}).json()
        self.assertEqual(self.client.get(f'/api/rooms/{self.room}',headers=self.headers(other)).status_code,403)
        self.assertEqual(self.client.post(f'/api/rooms/{self.room}/join',json={'join_key':'wrong','name':'زائر','role':'observer'}).status_code,403)
    def test_privilege_cannot_be_forged_in_command(self):
        observer=self.join('observer')
        self.assertEqual(self.action('CREATE',observer,role='operator',location='gate3',description='اختبار').status_code,400)
    def test_compare_and_swap_rejects_lost_update(self):
        revision=self.read()['revision'];body={'revision':revision,'command':{'type':'ROBOT','key':'battery','value':70}}
        self.assertEqual(self.client.post(f'/api/rooms/{self.room}/actions',headers=self.h,json=body).status_code,200)
        self.assertEqual(self.client.post(f'/api/rooms/{self.room}/actions',headers=self.h,json=body).status_code,409)
    def test_origin_and_headers(self):
        response=self.client.post('/api/rooms',headers={'origin':'https://elsewhere.invalid'},json={'name':'x'});self.assertEqual(response.status_code,403)
        self.assertEqual(self.client.get('/api/health').headers['cache-control'],'no-store')
    def test_report_and_calculation_envelope(self):
        response=self.action('CREATE',location='gate3',description='وصف مصطنع');m=response.json()['state']['missions'][0]
        self.assertIsNone(response.json()['calculations'][m['id']]['total'])
        report=self.client.get(f'/api/rooms/{self.room}/reports/{m["id"]}',headers=self.h).json();self.assertEqual(report['report']['source'],'SIMULATED_ONLY')
    def test_room_deletion_role(self):
        observer=self.join('observer')
        self.assertEqual(self.client.delete(f'/api/rooms/{self.room}',headers=self.headers(observer)).status_code,403)
        self.assertEqual(self.client.delete(f'/api/rooms/{self.room}',headers=self.h).status_code,200)
        self.assertEqual(self.client.get(f'/api/rooms/{self.room}',headers=self.h).status_code,403)
    def test_media_roundtrip_endpoint_isolation_and_end(self):
        medic=self.join();observer=self.join('observer');m=self.action('CREATE',location='gate3',description='بلاغ').json()['state']['missions'][0]
        c=self.action('CALL_START',id=m['id'],target_id=medic['member_id'],mode='test').json()['state']['calls'][0]
        self.assertEqual(self.action('CALL_ACCEPT',medic,call_id=c['id']).status_code,200)
        base=f'/api/rooms/{self.room}/media/{c["id"]}'
        clip=self.client.post(base,headers={**self.h,'content-type':'video/webm'},content=b'clip-data').json()['id']
        receiver=self.headers(medic);self.assertEqual(self.client.get(base,headers=receiver).json()['clips'][0]['id'],clip)
        self.assertEqual(self.client.get(base+'/'+clip,headers=receiver).content,b'clip-data')
        self.assertEqual(self.client.get(base,headers=self.headers(observer)).status_code,403)
        self.assertEqual(self.client.post(base,headers={**self.h,'content-type':'text/html'},content=b'<script>').status_code,415)
        self.action('CALL_END',call_id=c['id']);self.assertFalse((Path(self.tmp.name)/'media'/c['id']).exists())
        self.assertEqual(self.client.get(base,headers=receiver).status_code,409)
    def test_invalid_vision_image(self):
        try:import cv2
        except ImportError:self.skipTest('optional vision not installed')
        response=self.client.post(f'/api/rooms/{self.room}/vision',headers=self.h,files={'image':('test.png',b'not-an-image','image/png')})
        self.assertEqual(response.status_code,400)

class StorageTests(unittest.TestCase):
    def test_atomic_revision_under_concurrent_writers(self):
        with tempfile.TemporaryDirectory() as d:
            store=Store(d);owner=store.create('تشغيل');room=owner['room_id'];member=owner['member_id'];token=owner['member_token'];revision=store.read(room,member,token)['revision'];barrier=threading.Barrier(2)
            def writer(value):
                barrier.wait()
                try:store.mutate(room,member,token,revision,{'type':'ROBOT','key':'battery','value':value});return 'saved'
                except Conflict:return 'conflict'
            with ThreadPoolExecutor(2) as pool:results=list(pool.map(writer,[60,70]))
            self.assertCountEqual(results,['saved','conflict'])
    def test_clip_cleanup_removes_content_and_metadata(self):
        from uuid import uuid4
        with tempfile.TemporaryDirectory() as d:
            media=Media(d);call,sender=str(uuid4()),str(uuid4());clip=media.put(call,sender,b'123','video/webm');p=Path(d)/call/clip
            os.utime(p,(time.time()-30,time.time()-30));media.cleanup();self.assertFalse(p.exists());self.assertFalse(p.with_suffix('.type').exists())
