from copy import deepcopy
import unittest
from wisal.domain import *
from wisal.medical import demo_assessment

class DomainTests(unittest.TestCase):
    def setUp(self):
        self.now=1000;self.state=new_state(self.now);self.actors={role:{'id':role,'name':role,'role':role} for role in ROLES}
    def act(self,kind,role='operator',**extra):
        self.now+=1;c={'type':kind,**extra}
        if self.state['missions'] and 'id' not in c:c['id']=self.state['missions'][0]['id']
        self.state=apply(self.state,c,self.actors[role],self.now);return self.state
    def create(self):self.act('CREATE',location='gate3',description='حالة تجريبية')
    def arrive(self):
        self.create();self.act('VERIFY_REPORT',confirmed=True);self.act('ASSIGN');self.act('START_ROUTE')
        for _ in range(5):self.act('ADVANCE')
    def ready(self):
        self.arrive();self.act('SAVE_PRIMARY',primary={'scene':'safe','response':'A','breathing':'normal'});self.act('PERSON_CONFIRM',confirmed=True)
        self.act('DEMO_READINGS',complete=True);self.act('CARE_AUTHORIZE','medic',supervision=True,consent=True)
    def test_unverified_report_cannot_dispatch(self):
        self.create()
        with self.assertRaises(ValueError):self.act('ASSIGN')
        with self.assertRaises(ValueError):self.act('VERIFY_REPORT',confirmed=False)
    def test_role_guard_is_server_side(self):
        self.create()
        for role in ['robot','medic','observer']:
            with self.subTest(role=role),self.assertRaises(ValueError):self.act('VERIFY_REPORT',role,confirmed=True)
    def test_full_round_trip_requires_review(self):
        self.arrive();self.act('DEMO_READINGS',complete=False);self.act('SEND_REPORT')
        with self.assertRaises(ValueError):self.act('RETURN')
        self.act('REVIEW','medic',note='مراجعة تجريبية');self.act('RETURN')
        for _ in range(5):self.act('ADVANCE')
        self.assertEqual(self.state['missions'][0]['status'],'CLOSED')
        self.assertIsNone(self.state['missions'][0]['handover']['news2']['total'])
    def test_obstacle_clear_does_not_restart(self):
        self.create();self.act('VERIFY_REPORT',confirmed=True);self.act('ASSIGN');self.act('START_ROUTE');self.act('ROBOT',key='obstacle',value=True)
        with self.assertRaises(ValueError):self.act('ADVANCE')
        self.act('ROBOT',key='obstacle',value=False)
        with self.assertRaises(ValueError):self.act('ADVANCE')
        self.act('RESUME');self.act('ADVANCE');self.assertEqual(self.state['missions'][0]['progress'],20)
    def test_loss_link_estop_battery_each_block(self):
        self.create();self.act('VERIFY_REPORT',confirmed=True);self.act('ASSIGN');self.act('START_ROUTE')
        for key,value,restore in [('link',False,True),('estop',True,False),('battery',19,60)]:
            self.act('ROBOT',key=key,value=value)
            with self.assertRaises(ValueError):self.act('ADVANCE')
            self.act('ROBOT',key=key,value=restore)
            with self.assertRaises(ValueError):self.act('ADVANCE')
            self.act('RESUME')
    def test_single_robot_cannot_serve_two_missions(self):
        self.create();self.act('VERIFY_REPORT',confirmed=True);self.act('ASSIGN');self.create();self.act('VERIFY_REPORT',confirmed=True)
        with self.assertRaises(ValueError):self.act('ASSIGN')
    def test_person_scene_and_medic_authorization_required(self):
        self.arrive()
        with self.assertRaises(ValueError):self.act('DRAWER_OPEN')
        self.act('SAVE_PRIMARY',primary={'scene':'safe','response':'A','breathing':'normal'});self.act('PERSON_CONFIRM',confirmed=True)
        with self.assertRaises(ValueError):self.act('ARM_READY')
        with self.assertRaises(ValueError):self.act('CARE_AUTHORIZE','operator',supervision=True,consent=True)
        with self.assertRaises(ValueError):self.act('CARE_AUTHORIZE','medic',supervision=True,consent=False)
        self.act('CARE_AUTHORIZE','medic',supervision=True,consent=True);self.act('DRAWER_OPEN');self.assertEqual(self.state['robot']['drawer'],'OPEN')
    def test_arm_requires_ready_and_movement_requires_stowed_closed(self):
        self.ready()
        with self.assertRaises(ValueError):self.act('ARM_ASSIST_DEMO')
        self.act('DRAWER_OPEN');self.act('ARM_READY');self.act('ARM_ASSIST_DEMO');self.act('SEND_REPORT');self.act('REVIEW','medic',note='اطلعت على المحاكاة')
        with self.assertRaises(ValueError):self.act('RETURN')
        self.act('DRAWER_CLOSE')
        with self.assertRaises(ValueError):self.act('RETURN')
        self.act('ARM_STOW');self.act('RETURN')
    def test_stop_revokes_care(self):
        self.ready();self.act('STOP','observer');self.act('ROBOT',key='estop',value=False)
        with self.assertRaises(ValueError):self.act('DRAWER_OPEN')
    def test_change_invalidates_review_snapshot_and_care(self):
        self.ready();self.act('SEND_REPORT');self.act('REVIEW','medic',note='مراجعة')
        self.act('DEMO_READINGS',complete=False);m=self.state['missions'][0]
        self.assertIsNone(m['review']);self.assertIsNone(m['handover']);self.assertNotIn('care_authorization',m)
    def test_stale_assessment_form_cannot_overwrite(self):
        self.arrive();self.act('DEMO_READINGS',complete=False);saved=self.state['missions'][0]['assessment']['saved_at'];self.act('DEMO_READINGS',complete=True)
        with self.assertRaises(ValueError):self.act('SAVE_ASSESSMENT',assessment={},base_saved_at=saved)
    def test_unresponsive_blocks_optional_arm_even_with_authorization(self):
        self.ready();self.act('SAVE_PRIMARY',primary={'scene':'safe','response':'U','breathing':'absent'});self.act('CARE_AUTHORIZE','medic',supervision=True,consent=True)
        with self.assertRaises(ValueError):self.act('ARM_READY')
        with self.assertRaises(ValueError):self.act('DEMO_READINGS',complete=True)
    def test_expiry_and_input_are_validated_without_mutation(self):
        original=deepcopy(self.state)
        with self.assertRaises(ValueError):apply(self.state,{'type':'CREATE','location':'missing'},self.actors['operator'],1001)
        self.assertEqual(self.state,original)
        with self.assertRaises(ValueError):apply(self.state,{'type':'STOP'},self.actors['operator'],self.state['expires_at'])
    def test_real_actuation_is_disabled(self):
        from wisal.hardware import MockHardware
        with self.assertRaises(RuntimeError):MockHardware().real_command('arm','pressure')

    def test_stale_primary_form_cannot_overwrite(self):
        self.create();self.act('SAVE_PRIMARY',primary={'scene':'safe'});saved=self.state['missions'][0]['primary']['saved_at'];self.act('SAVE_PRIMARY',primary={'scene':'unsafe'})
        with self.assertRaises(ValueError):self.act('SAVE_PRIMARY',primary={'scene':'safe'},base_primary_saved_at=saved)
    def test_cancellation_ends_associated_demo_call(self):
        self.create();now=self.now
        self.state['participants']=[{'id':'medic','role':'medic','name':'المسعف','last_seen':now}]
        self.act('CALL_START',target_id='medic',mode='test');self.act('CANCEL')
        self.assertEqual(self.state['calls'][0]['status'],'ended')
