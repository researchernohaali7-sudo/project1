"""Build a standalone, owner-independent notebook containing the exact runnable source."""
from pathlib import Path
import base64
import hashlib
import io
import json
import zipfile

ROOT=Path(__file__).resolve().parents[1]
files=sorted(p for p in (ROOT/'wisal').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc'])
buf=io.BytesIO()
with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:
        info=zipfile.ZipInfo(p.relative_to(ROOT).as_posix(),date_time=(2026,11,14,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,p.read_bytes())
payload=buf.getvalue();encoded=base64.b64encode(payload).decode();digest=hashlib.sha256(payload).hexdigest()
cells=[]
def md(source):cells.append({'cell_type':'markdown','metadata':{},'source':source.splitlines(True)})
def code(source,hidden=False):cells.append({'cell_type':'code','execution_count':None,'metadata':{'cellView':'form'} if hidden else {},'outputs':[],'source':source.splitlines(True)})
md('''# وِصال | روبوت الاستجابة الأولية الأرضي

**ابدئي: Runtime → Run all ثم انزلي إلى اللوحة في آخر خلية. لا تحتاجين GPU أو تثبيتًا على جهازك.**

هذا برنامج لتجربة مهمة وِصال وفق التصميم المرفق: قاعدة بعجلات، كاميرا ومستشعرات قرب وLiDAR، شاشة، درج جانبي وذراع بخمس أصابع.

كل الحركة والقياسات والدرج والذراع **محاكاة مصطنعة**. المشاهدة تدخل بشريًا، والقرار للمختص؛ الاعتماد الطبي والربط بالأجهزة لم يتمّا.

| التبويب | ماذا تفعلين؟ |
|---|---|
| البلاغ والمسار | بلاغ ← تحقق بشري ← تكليف ← بدء ← خمس خطوات حتى الوصول |
| التقييم الأولي | سلامة المشهد والاستجابة والتنفس، ثم القياسات المصطنعة والتوثيق |
| الدرج والذراع | تحقق بشري، تصريح المسعف، فتح/إغلاق وتجهيز/تخزين محاكى |
| الرؤية الاختيارية | تحليل صورة لأشخاص محتملين مع تحقق بشري |
| التقرير والدليل | تسليم، مراجعة المسعف، عودة، وتنزيل تقرير |

زر **«رحلة عرض كاملة مصطنعة»** ينفذ الأدوار افتراضيًا لإظهار رحلة مكتملة. للتجربة اليدوية ابدئي «جلسة جديدة» وبدلي «دور العرض» أعلى اللوحة.

هذه خلايا تفاعلية في تشغيل واحد، وليست غرفة مشتركة بين مستخدمي Colab. جلسة الفريق الحقيقية والرسائل والصوت والصورة متاحة في نسخة المتصفح ضمن المشروع.
''')
md('''## ١ · الإعداد

اتركي الخيارين `False` للتشغيل الأسرع. تفعيل الرؤية يضيف OpenCV. تفعيل Drive يطلب وصله لحفظ حالة العرض بين بيئات Colab؛ خلاف ذلك حالة Colab مؤقتة. إعادة Run all في نفس البيئة تستأنف الحالة ولا تبدأ من الصفر.
''')
code('''# إعدادات اختيارية — لا تحتاجين تغييرها لبدء المحاكاة
ENABLE_VISION = False
SAVE_TO_DRIVE = False

import importlib.util, subprocess, sys
if importlib.util.find_spec("ipywidgets") is None:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "ipywidgets>=8.1,<9"])
if ENABLE_VISION and importlib.util.find_spec("cv2") is None:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "opencv-python-headless>=4.11,<5"])
try:
    from google.colab import output
    output.enable_custom_widget_manager()
except ImportError:
    pass
print("جاهز. ستظهر اللوحة بعد خلية التهيئة.")
''')
code('# @title ٢ · تهيئة برنامج وِصال (الشيفرة مضمنة؛ لا يحتاج رابط GitHub)\nimport base64, hashlib, io, sys, zipfile\nfrom pathlib import Path\n\nWISAL_ROOT = Path("/content/wisal-response-robot") if Path("/content").is_dir() else Path.cwd() / "wisal-response-robot"\nWISAL_ROOT.mkdir(parents=True, exist_ok=True)\n_wisal_payload = base64.b64decode(\n    "'+encoded+'"\n)\nassert hashlib.sha256(_wisal_payload).hexdigest() == "'+digest+'", "تعذر التحقق من سلامة الشيفرة"\nwith zipfile.ZipFile(io.BytesIO(_wisal_payload)) as _archive:\n    for _entry in _archive.infolist():\n        _target = (WISAL_ROOT / _entry.filename).resolve()\n        if not _target.is_relative_to(WISAL_ROOT.resolve()):\n            raise ValueError("مسار غير صالح داخل الحزمة")\n    _archive.extractall(WISAL_ROOT)\nif str(WISAL_ROOT) not in sys.path:\n    sys.path.insert(0, str(WISAL_ROOT))\nWISAL_DATA = WISAL_ROOT / "runtime_data" / "colab"\nif SAVE_TO_DRIVE:\n    try:\n        from google.colab import drive\n    except ImportError:\n        raise RuntimeError("خيار Drive مخصص لبيئة Colab؛ غيّريه إلى False هنا")\n    drive.mount("/content/drive")\n    WISAL_DATA = Path("/content/drive/MyDrive/WISAL_Demo/runtime_data")\nprint("تم تجهيز وِصال. الأجهزة والقياسات في وضع المحاكاة.")\n',True)
md('''## ٣ · لوحة التشغيل

**للشرح السريع:** اضغطي «رحلة عرض كاملة مصطنعة»، ثم افتحي «التقرير والدليل» واضغطي «عرض التقرير».

**للتجربة اليدوية:** اضغطي «جلسة جديدة». المشغلة تنشئ البلاغ وتتحقق وتكلف وتبدأ المسار. طرف وِصال يوثق التقييم ويتحقق من الشخص. المسعف يصدر تصريح الدرج والذراع ويراجع التقرير. المشغلة تبدأ العودة بعد إغلاق الدرج وتخزين الذراع.

إذا ظهر خطأ، فهو يوضح الشرط الناقص أو الدور المطلوب. بعد خمس خطوات يصل وِصال؛ وبعد خمس خطوات عودة تُغلق المهمة. عودة الاتصال وإزالة العائق تحتاجان «استئناف صريح».
''')
code('''from wisal.notebook import NotebookDashboard
# إعادة هذه الخلية تعرض آخر حالة محفوظة خلال صلاحية الجلسة.
wisal_dashboard = NotebookDashboard(WISAL_DATA)
wisal_dashboard.display()
''')
md('''## حدود ومصادر

- سلامة المشهد والانطباع العام ثم AVPU وABCDE. عدم الاستجابة: تصعيد فوري دون انتظار القياسات. اشتباه التوقف يظهر عند عدم الاستجابة مع تنفس غائب أو غير طبيعي وفق الإدخال. لا اتصال إسعافي خارجي أو علاج آلي.
- الحرارة والنبض وحدهما لا ينتجان NEWS2 كاملًا. المثال الكامل تعليمي، Scale 1، بمدخلات وأهلية معروفة. لا تشخيص أو قرار فرز آلي، ولا قياسات أجهزة حقيقية.
- الذراع والدرج افتراضيان فقط؛ لا قوة ضغط أو أوامر أجهزة. الرؤية قد تفوّت شخصًا مستلقيًا أو محجوبًا؛ عدم الكشف لا ينفي وجود شخص.
- اختُبرت الشيفرة وواجهة النوتبوك محليًا. تشغيلها في حساب Colab يعتمد على توفره وإذون ملفك؛ لا تزعم هذه الحزمة تنفيذ جلسة سحابية في حسابك.

[WHO BEC](https://www.who.int/publications/i/item/9789241513081) · [RCUK ABCDE](https://www.resus.org.uk/library/abcde-approach) · [RCUK BLS 2025](https://www.resus.org.uk/professional-library/2025-resuscitation-guidelines/adult-basic-life-support-guidelines) · [RCP NEWS2](https://www.rcp.ac.uk/resources/national-early-warning-score-news-2/) · [Colab FAQ](https://research.google.com/colaboratory/faq.html)
''')
notebook={'cells':cells,'metadata':{'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'language_info':{'name':'python','version':'3.12'},'colab':{'name':'WISAL_Robot_Colab.ipynb','provenance':[]}},'nbformat':4,'nbformat_minor':5}
for i,cell in enumerate(cells):cell['id']=f'wisal-{i+1:02d}'
output=ROOT/'WISAL_Robot_Colab.ipynb';output.write_text(json.dumps(notebook,ensure_ascii=False,indent=1)+'\n')
print(f'{output.name}: {output.stat().st_size:,} bytes; embedded source {len(payload):,} bytes')
