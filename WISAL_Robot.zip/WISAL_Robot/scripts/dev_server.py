"""Development preview adapter; normal usage: python -m uvicorn wisal.server:app."""
import argparse
import os
import sys
from pathlib import Path
import uvicorn
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
parser=argparse.ArgumentParser()
parser.add_argument('--host',default='127.0.0.1');parser.add_argument('--port',type=int,default=int(os.environ.get('PORT','8000')))
parser.add_argument('--strictPort',action='store_true')
args=parser.parse_args()
uvicorn.run('wisal.server:app',host=args.host,port=args.port)
